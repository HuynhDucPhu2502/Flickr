import React, { useEffect, useMemo, useState } from "react";
import {
  View,
  StyleSheet,
  ScrollView,
  Image,
  TouchableOpacity,
  Alert,
  Text,
  TextInput,
  ActivityIndicator,
  Modal,
  Pressable,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useNavigation } from "@react-navigation/native";
import { Ionicons } from "@expo/vector-icons";
import * as ImagePicker from "expo-image-picker";

import { useAuth } from "../../../../../contexts/auth";
import { auth, db } from "../../../../../FirebaseConfig";
import { collection, onSnapshot, orderBy, query } from "firebase/firestore";
import { updateProfileFields } from "../../../../../services/auth";
import { updateProfile as fbUpdateProfile } from "firebase/auth";

import {
  uploadPhotoFromUri,
  deletePhoto,
  setMainPhoto,
} from "../../../../../services/profilePhoto";

// --- types & colors ---
type PhotoDoc = {
  id: string;
  url: string;
  storagePath: string;
  width: number;
  height: number;
  isMain: boolean;
  order: number;
  uploadedAt: any;
  deletedAt?: any;
};
type Panel =
  | null
  | "name"
  | "birthday"
  | "occupation"
  | "gender"
  | "education"
  | "location"
  | "preferences";

const PURPLE = "#6C63FF";
const PURPLE_SOFT = "#F1EDFF";
const TEXT_MUTE = "#6C6C80";

export const ProfileEditScreen = () => {
  const insets = useSafeAreaInsets();
  const nav = useNavigation();
  const { user, profile } = useAuth();
  const uid = user?.uid!;

  const [panel, setPanel] = useState<Panel>(null);
  const [loadingPhotos, setLoadingPhotos] = useState(true);
  const [photos, setPhotos] = useState<PhotoDoc[]>([]);
  const mainPhoto = useMemo(
    () => photos.find((p) => p.isMain) ?? photos[0],
    [photos]
  );

  // ---- Local editable states
  const [about, setAbout] = useState("");
  const [interests, setInterests] = useState<string[]>([]);
  const [newInterest, setNewInterest] = useState("");
  const [langs, setLangs] = useState<string[]>([]);
  const [newLang, setNewLang] = useState("");

  // ---- Dirty flags để không bị snapshot ghi đè khi đang gõ
  const [dirty, setDirty] = useState({
    about: false,
    interests: false,
    langs: false,
  });

  // Chỉ đồng bộ các field khi chúng đổi và khi không dirty
  useEffect(() => {
    if (!profile) return;
    setAbout((prev) => (dirty.about ? prev : profile.bio ?? ""));
  }, [profile?.bio]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!profile) return;
    setInterests((prev) => (dirty.interests ? prev : profile.interests ?? []));
  }, [profile?.interests]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!profile) return;
    setLangs((prev) => (dirty.langs ? prev : profile.languages ?? []));
  }, [profile?.languages]); // eslint-disable-line react-hooks/exhaustive-deps

  // Photos listener
  useEffect(() => {
    if (!uid) return;
    const q = query(
      collection(db, `users/${uid}/photos`),
      orderBy("order", "desc")
    );
    const unsub = onSnapshot(
      q,
      (snap) => {
        const list: PhotoDoc[] = [];
        snap.forEach((d) => {
          const data = d.data() as PhotoDoc;
          if (!data.deletedAt) list.push(data);
        });
        setPhotos(list);
        setLoadingPhotos(false);
      },
      () => setLoadingPhotos(false)
    );
    return () => unsub();
  }, [uid]);

  const pickAndUpload = async () => {
    try {
      const res = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ["images"] as any,
        allowsEditing: true,
        quality: 0.9,
      });
      if (res.canceled) return;
      const asset = res.assets[0];
      await uploadPhotoFromUri(uid, asset.uri, {
        makeMain: photos.length === 0,
        width: asset.width,
        height: asset.height,
      });
    } catch (e: any) {
      Alert.alert("Upload ảnh thất bại", e?.message ?? String(e));
    }
  };

  const confirmDelete = (p: PhotoDoc) => {
    Alert.alert("Xoá ảnh?", "Ảnh sẽ bị xoá khỏi hồ sơ của bạn.", [
      { text: "Huỷ", style: "cancel" },
      {
        text: "Xoá",
        style: "destructive",
        onPress: async () => {
          try {
            await deletePhoto(uid, p.storagePath, p.id);
          } catch (e: any) {
            Alert.alert("Lỗi xoá ảnh", e?.message ?? String(e));
          }
        },
      },
    ]);
  };

  const setAsMain = async (p: PhotoDoc) => {
    try {
      await setMainPhoto(uid, p.id, p.url);
    } catch (e: any) {
      Alert.alert("Lỗi đặt ảnh chính", e?.message ?? String(e));
    }
  };

  const completion = useMemo(() => {
    if (!profile) return 0;
    const checks = [
      !!(mainPhoto?.url || profile.photoURL),
      !!(about || profile.bio),
      !!profile.displayName,
      !!profile.birthday,
      !!profile.occupation?.title,
      !!profile.gender,
      !!profile.education?.level && profile.education?.level !== "other",
      (interests.length || (profile.interests?.length ?? 0)) > 0,
      (langs.length || (profile.languages?.length ?? 0)) > 0,
      !!profile.location?.city,
      profile.preferences?.genders?.length,
    ];
    const done = checks.filter(Boolean).length;
    return Math.round((done / checks.length) * 100);
  }, [profile, mainPhoto, about, interests, langs]);

  const pushIfNotExist = (arr: string[], item: string) => {
    const v = item.trim();
    if (!v) return arr;
    if (arr.some((x) => x.toLowerCase() === v.toLowerCase())) return arr;
    return [...arr, v];
  };

  const saveQuickFields = async () => {
    try {
      const hasMainPhoto = !!(mainPhoto?.url || profile?.photoURL);
      const hasName = !!profile?.displayName?.trim();
      const hasGender = !!profile?.gender;
      const hasBirthday = !!profile?.birthday;

      const shouldOnboard =
        !profile?.onboarded &&
        hasMainPhoto &&
        hasName &&
        hasGender &&
        hasBirthday;

      await updateProfileFields(uid, {
        bio: about,
        interests,
        languages: langs,
        ...(shouldOnboard ? { onboarded: true } : {}),
      });

      // đã sync xong → cho phép nhận snapshot mới
      setDirty({ about: false, interests: false, langs: false });

      Alert.alert(
        "Đã lưu",
        shouldOnboard
          ? "Hồ sơ đã sẵn sàng để hiển thị."
          : "Hồ sơ đã được cập nhật."
      );
    } catch (e: any) {
      Alert.alert("Lỗi lưu", e?.message ?? String(e));
    }
  };

  // Tóm tắt Preferences (tuổi + giới)
  const pref = profile?.preferences ?? {};
  const prefPreview = useMemo(() => {
    const aMin = pref.ageMin ?? 18;
    const aMax = pref.ageMax ?? 40;
    const gs =
      pref.genders && pref.genders.length ? pref.genders.join("/") : "all";
    return `${aMin}-${aMax} • ${gs}`;
  }, [profile?.preferences]);

  return (
    <LinearGradient colors={["#B993D6", "#8CA6DB"]} style={{ flex: 1 }}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: insets.top + 8 }]}>
        <TouchableOpacity onPress={() => nav.goBack()}>
          <Ionicons name="arrow-back" size={26} color="#fff" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Edit profile</Text>
        <View style={{ width: 26 }} />
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingBottom: insets.bottom + 32 }}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        {/* Progress */}
        <Section>
          <Text style={styles.sectionTitle}>Profile completion</Text>
          <View style={styles.progressWrap}>
            <View style={[styles.progressBar, { width: `${completion}%` }]} />
          </View>
          <Text style={styles.progressText}>{completion}%</Text>
        </Section>

        {/* Photos */}
        <Section>
          <Text style={styles.sectionTitle}>Photos</Text>
          <Text style={styles.subText}>
            The main photo is how you appear to others on the swipe view.
          </Text>

          {loadingPhotos ? (
            <View style={{ paddingVertical: 24, alignItems: "center" }}>
              <ActivityIndicator />
            </View>
          ) : (
            <View style={styles.photoGrid}>
              <PhotoItem
                uri={mainPhoto?.url}
                big
                label={mainPhoto ? "Main" : undefined}
                onAdd={pickAndUpload}
                onDelete={
                  mainPhoto ? () => confirmDelete(mainPhoto) : undefined
                }
              />
              {Array.from({ length: 3 }).map((_, i) => {
                const p = photos.filter((x) => !x.isMain)[i];
                return (
                  <PhotoItem
                    key={i}
                    uri={p?.url}
                    onAdd={pickAndUpload}
                    onDelete={p ? () => confirmDelete(p) : undefined}
                    onMakeMain={p ? () => setAsMain(p) : undefined}
                  />
                );
              })}
            </View>
          )}
        </Section>

        {/* About me */}
        <Section>
          <Text style={styles.sectionTitle}>About me</Text>
          <Text style={styles.subText}>
            Make it easy for others to get a sense of who you are.
          </Text>
          <RNInput
            placeholder="Share a few words about yourself..."
            value={about}
            onChangeText={(t) => {
              setAbout(t);
              setDirty((d) => ({ ...d, about: true }));
            }}
            multiline
            numberOfLines={5}
          />
        </Section>

        {/* My details */}
        <Section>
          <Text style={styles.sectionTitle}>My details</Text>

          <RowItem
            icon="person-circle-outline"
            title="Name"
            value={profile?.displayName || user?.displayName || undefined}
            onPress={() => setPanel("name")}
          />

          <RowItem
            icon="calendar-outline"
            title="Birthday"
            value={profile?.birthday || undefined}
            onPress={() => setPanel("birthday")}
          />

          <RowItem
            icon="briefcase-outline"
            title="Occupation"
            value={profile?.occupation?.title}
            onPress={() => setPanel("occupation")}
          />

          <RowItem
            icon="person-outline"
            title="Gender"
            value={profile?.gender || undefined}
            onPress={() => setPanel("gender")}
          />

          <RowItem
            icon="school-outline"
            title="Education"
            value={
              profile?.education?.level && profile.education.level !== "other"
                ? profile.education.level
                : undefined
            }
            onPress={() => setPanel("education")}
          />

          <RowItem
            icon="location-outline"
            title="Location"
            value={
              [profile?.location?.city, profile?.location?.region]
                .filter(Boolean)
                .join(", ") || undefined
            }
            onPress={() => setPanel("location")}
          />
        </Section>

        {/* Discovery preferences */}
        <Section>
          <Text style={styles.sectionTitle}>Discovery preferences</Text>
          <RowItem
            icon="options-outline"
            title="Preferences"
            value={prefPreview}
            onPress={() => setPanel("preferences")}
          />
        </Section>

        {/* I enjoy */}
        <Section>
          <Text style={styles.sectionTitle}>I enjoy</Text>
          <Text style={styles.subText}>
            Adding your interest is a great way to find like-minded connections.
          </Text>
          <View style={styles.chipsWrap}>
            {interests.map((it) => (
              <Pill
                key={it}
                label={it}
                onClose={() => {
                  setInterests((arr) => arr.filter((x) => x !== it));
                  setDirty((d) => ({ ...d, interests: true }));
                }}
              />
            ))}
          </View>
          <View style={styles.inline}>
            <RNInput
              placeholder="Add an interest"
              value={newInterest}
              onChangeText={setNewInterest}
              style={{ marginTop: 0, width: "100%" }}
              returnKeyType="done"
              onSubmitEditing={() => {
                setInterests((a) => {
                  const next = pushIfNotExist(a, newInterest);
                  return next;
                });
                setDirty((d) => ({ ...d, interests: true }));
                setNewInterest("");
              }}
            />
            <PrimaryButton
              title="Add"
              onPress={() => {
                setInterests((a) => {
                  const next = pushIfNotExist(a, newInterest);
                  return next;
                });
                setDirty((d) => ({ ...d, interests: true }));
                setNewInterest("");
              }}
              style={{ alignSelf: "flex-start" }}
            />
          </View>
        </Section>

        {/* I communicate in */}
        <Section>
          <Text style={styles.sectionTitle}>I communicate in</Text>
          <View style={styles.chipsWrap}>
            {langs.map((lg) => (
              <Pill
                key={lg}
                label={lg}
                onClose={() => {
                  setLangs((arr) => arr.filter((x) => x !== lg));
                  setDirty((d) => ({ ...d, langs: true }));
                }}
              />
            ))}
          </View>
          <View style={styles.inline}>
            <RNInput
              placeholder="Add a language"
              value={newLang}
              onChangeText={setNewLang}
              style={{ marginTop: 0, width: "100%" }}
              returnKeyType="done"
              onSubmitEditing={() => {
                setLangs((a) => {
                  const next = pushIfNotExist(a, newLang);
                  return next;
                });
                setDirty((d) => ({ ...d, langs: true }));
                setNewLang("");
              }}
            />
            <PrimaryButton
              title="Add"
              onPress={() => {
                setLangs((a) => {
                  const next = pushIfNotExist(a, newLang);
                  return next;
                });
                setDirty((d) => ({ ...d, langs: true }));
                setNewLang("");
              }}
              style={{ alignSelf: "flex-start" }}
            />
          </View>
        </Section>

        {/* Save */}
        <View style={{ paddingHorizontal: 16, marginTop: 20 }}>
          <PrimaryButton
            title="Save changes"
            onPress={saveQuickFields}
            icon="save-outline"
          />
        </View>

        <View style={{ height: 24 }} />
      </ScrollView>

      {/* ======= Detail Editors (Bottom Sheet) ======= */}
      {/* Name */}
      <DetailSheet
        visible={panel === "name"}
        title="Name"
        onClose={() => setPanel(null)}
        onSave={async (form) => {
          const name = (form.displayName as string)?.trim() || "";
          if (!name) {
            Alert.alert("Thiếu tên", "Please enter your name.");
            return;
          }
          await updateProfileFields(uid, { displayName: name });
          if (auth.currentUser && auth.currentUser.uid === uid) {
            await fbUpdateProfile(auth.currentUser, { displayName: name });
          }
          setPanel(null);
        }}
        initial={{
          displayName: profile?.displayName ?? user?.displayName ?? "",
        }}
        fields={[
          { key: "displayName", label: "Your name", placeholder: "e.g. Alex" },
        ]}
      />

      {/* Birthday */}
      <DetailSheet
        visible={panel === "birthday"}
        title="Birthday"
        onClose={() => setPanel(null)}
        onSave={async (form) => {
          const b = (form.birthday as string)?.trim() || "";
          if (b && !/^\d{4}-\d{2}-\d{2}$/.test(b)) {
            Alert.alert("Định dạng sai", "Use YYYY-MM-DD (e.g., 2000-12-31).");
            return;
          }
          await updateProfileFields(uid, { birthday: b || null });
          setPanel(null);
        }}
        initial={{ birthday: profile?.birthday ?? "" }}
        fields={[
          {
            key: "birthday",
            label: "YYYY-MM-DD",
            placeholder: "e.g. 2000-12-31",
          },
        ]}
      />

      {/* Occupation */}
      <DetailSheet
        visible={panel === "occupation"}
        title="Occupation"
        onClose={() => setPanel(null)}
        onSave={async (form) => {
          await updateProfileFields(uid, {
            occupation: {
              title: form.title?.trim() || undefined,
              company: form.company?.trim() || undefined,
            },
          });
          setPanel(null);
        }}
        initial={{
          title: profile?.occupation?.title ?? "",
          company: profile?.occupation?.company ?? "",
        }}
        fields={[
          {
            key: "title",
            label: "Title",
            placeholder: "e.g. Software Engineer",
          },
          { key: "company", label: "Company", placeholder: "e.g. ACME Inc." },
        ]}
      />

      {/* Gender */}
      <DetailSheet
        visible={panel === "gender"}
        title="Gender"
        onClose={() => setPanel(null)}
        onSave={async (form) => {
          await updateProfileFields(uid, {
            gender: form.gender || null,
          });
          setPanel(null);
        }}
        initial={{ gender: (profile?.gender as string) ?? "" }}
        renderBody={(state, setState) => (
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
            {["male", "female", "nonbinary", "prefer_not_to_say", "custom"].map(
              (g) => (
                <Pressable
                  key={g}
                  onPress={() => setState((s: any) => ({ ...s, gender: g }))}
                  style={[
                    styles.chipBtn,
                    state.gender === g && {
                      backgroundColor: PURPLE,
                      borderColor: PURPLE,
                    },
                  ]}
                >
                  <Text
                    style={[
                      styles.chipBtnText,
                      state.gender === g && { color: "#fff" },
                    ]}
                  >
                    {g}
                  </Text>
                </Pressable>
              )
            )}
          </View>
        )}
      />

      {/* Education */}
      <DetailSheet
        visible={panel === "education"}
        title="Education"
        onClose={() => setPanel(null)}
        onSave={async (form) => {
          await updateProfileFields(uid, {
            education: {
              level: form.level || "other",
              school: form.school?.trim() || undefined,
            },
          });
          setPanel(null);
        }}
        initial={{
          level: (profile?.education?.level as string) ?? "other",
          school: profile?.education?.school ?? "",
        }}
        renderBody={(state, setState) => (
          <>
            <View
              style={{
                flexDirection: "row",
                flexWrap: "wrap",
                gap: 8,
                marginBottom: 12,
              }}
            >
              {["high_school", "bachelor", "master", "phd", "other"].map(
                (lv) => (
                  <Pressable
                    key={lv}
                    onPress={() => setState((s: any) => ({ ...s, level: lv }))}
                    style={[
                      styles.chipBtn,
                      state.level === lv && {
                        backgroundColor: PURPLE,
                        borderColor: PURPLE,
                      },
                    ]}
                  >
                    <Text
                      style={[
                        styles.chipBtnText,
                        state.level === lv && { color: "#fff" },
                      ]}
                    >
                      {lv}
                    </Text>
                  </Pressable>
                )
              )}
            </View>
            <RNInput
              placeholder="School / University"
              value={(state.school as string) ?? ""}
              onChangeText={(t) => setState((s: any) => ({ ...s, school: t }))}
            />
          </>
        )}
      />

      {/* Location */}
      <DetailSheet
        visible={panel === "location"}
        title="Location"
        onClose={() => setPanel(null)}
        onSave={async (form) => {
          await updateProfileFields(uid, {
            location: {
              city: form.city?.trim() || undefined,
              region: form.region?.trim() || undefined,
            },
          });
          setPanel(null);
        }}
        initial={{
          city: profile?.location?.city ?? "",
          region: profile?.location?.region ?? "",
        }}
        fields={[
          { key: "city", label: "City", placeholder: "e.g. Ho Chi Minh City" },
          {
            key: "region",
            label: "District/Province",
            placeholder: "e.g. District 1",
          },
        ]}
      />

      {/* Preferences (Age + Genders) */}
      <DetailSheet
        visible={panel === "preferences"}
        title="Discovery preferences"
        onClose={() => setPanel(null)}
        onSave={async (form) => {
          const clamp = (n: number, lo: number, hi: number) =>
            Math.max(lo, Math.min(hi, n));
          let ageMin = clamp(Number(form.ageMin) || 18, 18, 80);
          let ageMax = clamp(Number(form.ageMax) || 40, ageMin, 80);
          const genders =
            Array.isArray(form.genders) && form.genders.length
              ? form.genders
              : ["female", "male", "nonbinary"];

          await updateProfileFields(uid, {
            preferences: { ageMin, ageMax, genders },
          });
          setPanel(null);
        }}
        initial={{
          ageMin: profile?.preferences?.ageMin ?? 18,
          ageMax: profile?.preferences?.ageMax ?? 40,
          genders: profile?.preferences?.genders ?? [
            "female",
            "male",
            "nonbinary",
          ],
        }}
        renderBody={(state, setState) => {
          const set = (k: string, v: any) =>
            setState((s: any) => ({ ...s, [k]: v }));
          const genders: Array<"female" | "male" | "nonbinary"> = [
            "female",
            "male",
            "nonbinary",
          ];
          const selectedGenders: string[] = state.genders ?? [];

          return (
            <View style={{ gap: 12 }}>
              <Text style={styles.sheetSubTitle}>Age range</Text>
              <View style={{ gap: 8 }}>
                <Stepper
                  label="Min"
                  value={Number(state.ageMin) || 18}
                  min={18}
                  max={80}
                  onChange={(v: number) => {
                    const max = Math.max(v, Number(state.ageMax) || 40);
                    set("ageMin", v);
                    set("ageMax", max);
                  }}
                />
                <Stepper
                  label="Max"
                  value={Number(state.ageMax) || 40}
                  min={Number(state.ageMin) || 18}
                  max={80}
                  onChange={(v: number) => set("ageMax", v)}
                />
              </View>

              <Text style={styles.sheetSubTitle}>Show me</Text>
              <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
                {genders.map((g) => {
                  const sel = selectedGenders.includes(g);
                  return (
                    <Pressable
                      key={g}
                      onPress={() =>
                        set(
                          "genders",
                          sel
                            ? selectedGenders.filter((x) => x !== g)
                            : [...selectedGenders, g]
                        )
                      }
                      style={[
                        styles.chipBtn,
                        sel && { backgroundColor: PURPLE, borderColor: PURPLE },
                      ]}
                    >
                      <Text
                        style={[styles.chipBtnText, sel && { color: "#fff" }]}
                      >
                        {g}
                      </Text>
                    </Pressable>
                  );
                })}
              </View>
            </View>
          );
        }}
      />
    </LinearGradient>
  );
};

/* ===== UI primitives (no Paper) ===== */
const Section: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <View style={styles.section}>{children}</View>
);

const RNInput: React.FC<
  React.ComponentProps<typeof TextInput> & { errorText?: string }
> = ({ style, errorText, ...props }) => (
  <View style={{ marginTop: 10 }}>
    <TextInput
      {...props}
      style={[styles.input, style]}
      placeholderTextColor="#9AA0B4"
    />
    {errorText ? <Text style={styles.inputError}>{errorText}</Text> : null}
  </View>
);

const PrimaryButton: React.FC<{
  title: string;
  onPress?: () => void;
  style?: any;
  icon?: keyof typeof Ionicons.glyphMap;
}> = ({ title, onPress, style, icon }) => (
  <TouchableOpacity
    onPress={onPress}
    activeOpacity={0.8}
    style={[styles.btn, style]}
  >
    {icon ? (
      <Ionicons name={icon} size={18} color="#fff" style={{ marginRight: 6 }} />
    ) : null}
    <Text style={styles.btnText}>{title}</Text>
  </TouchableOpacity>
);

const Pill: React.FC<{ label: string; onClose?: () => void }> = ({
  label,
  onClose,
}) => (
  <View style={styles.pill}>
    <Text style={{ color: "#333" }}>{label}</Text>
    {onClose ? (
      <TouchableOpacity onPress={onClose} style={{ marginLeft: 6 }}>
        <Ionicons name="close" size={14} color="#666" />
      </TouchableOpacity>
    ) : null}
  </View>
);

const RowItem = ({
  icon,
  title,
  value,
  onPress,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  title: string;
  value?: string;
  onPress?: () => void;
}) => {
  const isAdd = !value;
  return (
    <TouchableOpacity style={styles.row} onPress={onPress} activeOpacity={0.8}>
      <View style={styles.rowLeft}>
        <Ionicons name={icon} size={18} color={PURPLE} />
        <Text style={styles.rowTitle}>{title}</Text>
      </View>
      <View style={styles.rowRight}>
        <Text style={[styles.rowValue, isAdd && { color: PURPLE }]}>
          {isAdd ? "Add" : value}
        </Text>
        <Ionicons name="chevron-forward" size={18} color="#9A9AAF" />
      </View>
    </TouchableOpacity>
  );
};

const PhotoItem = ({
  uri,
  label,
  big,
  onAdd,
  onDelete,
  onMakeMain,
}: {
  uri?: string;
  label?: string;
  big?: boolean;
  onAdd: () => void;
  onDelete?: () => void;
  onMakeMain?: () => void;
}) => {
  const size = big ? 190 : 100;
  return (
    <View
      style={[
        styles.photoBox,
        { width: big ? 190 : 100, height: big ? 190 : 100 },
      ]}
    >
      {uri ? (
        <>
          <Image
            source={{ uri }}
            style={{ width: size, height: size, borderRadius: 16 }}
          />
          <View style={styles.photoActions}>
            {onMakeMain && (
              <TouchableOpacity style={styles.actionBtn} onPress={onMakeMain}>
                <Ionicons name="star" size={16} color="#FFD54F" />
              </TouchableOpacity>
            )}
            {onDelete && (
              <TouchableOpacity style={styles.actionBtn} onPress={onDelete}>
                <Ionicons name="trash-outline" size={16} color="#fff" />
              </TouchableOpacity>
            )}
          </View>
          {label && (
            <View style={styles.photoLabel}>
              <Text style={{ color: "#fff", fontWeight: "700", fontSize: 12 }}>
                {label}
              </Text>
            </View>
          )}
        </>
      ) : (
        <TouchableOpacity
          style={styles.addBox}
          onPress={onAdd}
          activeOpacity={0.8}
        >
          <Ionicons name="add" size={24} color={PURPLE} />
        </TouchableOpacity>
      )}
    </View>
  );
};

/* ===== Extra compact UI controls ===== */
const Stepper: React.FC<{
  label: string;
  value: number;
  onChange: (n: number) => void;
  min: number;
  max: number;
}> = ({ label, value, onChange, min, max }) => (
  <View style={styles.stepper}>
    <Text style={{ fontWeight: "700", color: "#2B2B3D" }}>{label}</Text>
    <View style={styles.stepperControls}>
      <Pressable
        style={styles.stepBtn}
        onPress={() => onChange(Math.max(min, value - 1))}
      >
        <Ionicons name="remove" size={18} color="#fff" />
      </Pressable>
      <Text style={styles.stepNum}>{value}</Text>
      <Pressable
        style={styles.stepBtn}
        onPress={() => onChange(Math.min(max, value + 1))}
      >
        <Ionicons name="add" size={18} color="#fff" />
      </Pressable>
    </View>
  </View>
);

/* ===== Bottom sheet detail editor ===== */
const DetailSheet: React.FC<{
  visible: boolean;
  title: string;
  onClose: () => void;
  onSave: (form: Record<string, any>) => Promise<void> | void;
  initial?: Record<string, any>;
  fields?: Array<{ key: string; label: string; placeholder?: string }>;
  renderBody?: (
    state: Record<string, any>,
    setState: React.Dispatch<any>
  ) => React.ReactNode;
}> = ({
  visible,
  title,
  onClose,
  onSave,
  initial = {},
  fields,
  renderBody,
}) => {
  const [state, setState] = useState<Record<string, any>>(initial);
  useEffect(() => setState(initial), [visible]);

  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      onRequestClose={onClose}
    >
      <Pressable style={styles.sheetBackdrop} onPress={onClose} />
      <View style={styles.sheet}>
        <View style={styles.sheetHeader}>
          <Text style={styles.sheetTitle}>{title}</Text>
          <TouchableOpacity onPress={onClose}>
            <Ionicons name="close" size={22} color="#333" />
          </TouchableOpacity>
        </View>

        <View style={{ paddingHorizontal: 14, paddingBottom: 14 }}>
          {renderBody
            ? renderBody(state, setState)
            : fields?.map((f) => (
                <RNInput
                  key={f.key}
                  placeholder={f.placeholder || f.label}
                  value={(state[f.key] as string) ?? ""}
                  onChangeText={(t) => setState((s) => ({ ...s, [f.key]: t }))}
                />
              ))}
          <PrimaryButton
            title="Save"
            onPress={() => onSave(state)}
            style={{ marginTop: 12 }}
          />
        </View>
      </View>
    </Modal>
  );
};

/* ===== styles ===== */
const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    paddingHorizontal: 12,
    paddingBottom: 8,
  },
  headerTitle: { color: "#fff", fontSize: 18, fontWeight: "700" },

  section: {
    backgroundColor: PURPLE_SOFT,
    marginHorizontal: 12,
    marginTop: 12,
    padding: 14,
    borderRadius: 16,
  },
  sectionTitle: { fontWeight: "800", fontSize: 16, color: "#2B2B3D" },
  subText: { color: TEXT_MUTE, marginTop: 6 },

  progressWrap: {
    marginTop: 8,
    height: 10,
    borderRadius: 10,
    backgroundColor: "#E6E2FF",
    overflow: "hidden",
  },
  progressBar: { height: "100%", backgroundColor: PURPLE, borderRadius: 10 },
  progressText: { marginTop: 6, color: TEXT_MUTE, fontWeight: "600" },

  photoGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    columnGap: 12,
    rowGap: 12,
    marginTop: 12,
  },
  photoBox: { backgroundColor: "#fff", borderRadius: 16, overflow: "hidden" },
  addBox: {
    flex: 1,
    width: "100%",
    height: "100%",
    backgroundColor: "#fff",
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
  },
  photoActions: {
    position: "absolute",
    top: 8,
    right: 8,
    flexDirection: "row",
    gap: 6,
  },
  actionBtn: {
    backgroundColor: "rgba(0,0,0,0.35)",
    paddingVertical: 4,
    paddingHorizontal: 6,
    borderRadius: 10,
  },
  photoLabel: {
    position: "absolute",
    left: 8,
    bottom: 8,
    backgroundColor: "rgba(0,0,0,0.45)",
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },

  input: {
    backgroundColor: "#fff",
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 15,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: "#E2E6F0",
  },
  inputError: { marginTop: 4, color: "#e53935", fontSize: 12 },

  inline: {
    marginTop: 10,
    alignItems: "stretch",
    gap: 8,
  },

  chipsWrap: { flexDirection: "row", flexWrap: "wrap", gap: 8, marginTop: 10 },
  pill: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    borderRadius: 999,
    paddingHorizontal: 12,
    paddingVertical: 6,
  },

  row: { flexDirection: "row", alignItems: "center", paddingVertical: 14 },
  rowLeft: { flexDirection: "row", alignItems: "center", gap: 10 },
  rowTitle: { fontWeight: "600", color: "#2B2B3D" },
  rowRight: {
    marginLeft: "auto",
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  rowValue: { color: TEXT_MUTE },

  btn: {
    backgroundColor: PURPLE,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
  },
  btnText: { color: "#fff", fontWeight: "700" },

  // sheet
  sheetBackdrop: {
    position: "absolute",
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    backgroundColor: "rgba(0,0,0,0.25)",
  },
  sheet: {
    position: "absolute",
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: "#fff",
    borderTopLeftRadius: 18,
    borderTopRightRadius: 18,
  },
  sheetHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 14,
    paddingTop: 12,
    paddingBottom: 8,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderColor: "#eee",
  },
  sheetTitle: { fontSize: 16, fontWeight: "700" },
  sheetSubTitle: { fontWeight: "700", color: "#2B2B3D", marginTop: 6 },

  chipBtn: {
    borderWidth: 1,
    borderColor: "#D4D7E2",
    borderRadius: 999,
    paddingHorizontal: 12,
    paddingVertical: 8,
    backgroundColor: "#fff",
  },
  chipBtnText: { color: "#333" },

  // compact controls (Stepper)
  stepper: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    backgroundColor: "#fff",
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: "#E2E6F0",
  },
  stepperControls: { flexDirection: "row", alignItems: "center", gap: 8 },
  stepBtn: {
    width: 32,
    height: 32,
    borderRadius: 8,
    backgroundColor: PURPLE,
    alignItems: "center",
    justifyContent: "center",
  },
  stepNum: {
    minWidth: 36,
    textAlign: "center",
    fontWeight: "700",
    color: "#333",
  },
});
