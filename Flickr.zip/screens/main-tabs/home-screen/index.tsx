// screens/home/HomeScreen.tsx
import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  View,
  Text,
  Image,
  StyleSheet,
  Dimensions,
  Animated,
  PanResponder,
  TouchableOpacity,
  Modal,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useAuth } from "../../../contexts/auth";
import {
  Candidate,
  fetchCandidates,
  swipeLeft,
  swipeRight,
} from "../../../services/swipe";

const { width } = Dimensions.get("window");
const CARD_W = width - 32;
const CARD_H = CARD_W * 1.35;

// 💜 New color palette
const PURPLE_LIGHT = "#C084FC";
const PURPLE_DARK = "#9333EA";
const PURPLE_BG1 = "#F3E8FF";
const PURPLE_BG2 = "#EDE9FE";
const GRAY_TEXT = "#6B7280";

export const HomeScreen = () => {
  const insets = useSafeAreaInsets();
  const { user, profile } = useAuth();
  const uid = user?.uid!;

  const [cards, setCards] = useState<Candidate[]>([]);
  const [loading, setLoading] = useState(true);
  const [matchModal, setMatchModal] = useState<{
    me?: Candidate;
    them?: Candidate;
    visible: boolean;
  }>({ visible: false });

  // ===== Load feed
  useEffect(() => {
    let mounted = true;
    (async () => {
      if (!uid) return;
      setLoading(true);
      try {
        const list = await fetchCandidates(uid, profile?.preferences, 25);
        if (mounted) {
          setCards(list);
          setLoading(false);
        }
      } catch (err) {
        console.error("❌ [HomeScreen] Fetch error:", err);
        if (mounted) setLoading(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, [
    uid,
    profile?.preferences?.ageMin,
    profile?.preferences?.ageMax,
    profile?.preferences?.genders?.join(","),
  ]);

  // ===== Swipe engine
  const pan = useRef(new Animated.ValueXY()).current;
  const [history, setHistory] = useState<Candidate[]>([]);

  const rotate = pan.x.interpolate({
    inputRange: [-150, 0, 150],
    outputRange: ["-10deg", "0deg", "10deg"],
  });
  const likeOpacity = pan.x.interpolate({
    inputRange: [0, 120],
    outputRange: [0, 1],
    extrapolate: "clamp",
  });
  const nopeOpacity = pan.x.interpolate({
    inputRange: [-120, 0],
    outputRange: [1, 0],
    extrapolate: "clamp",
  });

  const topCard = cards[0];
  const nextCard = cards[1];

  const panResponder = useMemo(
    () =>
      PanResponder.create({
        onMoveShouldSetPanResponder: (_, g) =>
          Math.abs(g.dx) > 4 || Math.abs(g.dy) > 4,
        onPanResponderMove: Animated.event([null, { dx: pan.x, dy: pan.y }], {
          useNativeDriver: false,
        }),
        onPanResponderRelease: (_, g) => {
          if (g.dx > 120) {
            forceSwipe("right");
          } else if (g.dx < -120) {
            forceSwipe("left");
          } else {
            Animated.spring(pan, {
              toValue: { x: 0, y: 0 },
              useNativeDriver: false,
            }).start();
          }
        },
      }),
    []
  );

  const forceSwipe = (dir: "left" | "right") => {
    Animated.timing(pan, {
      toValue: { x: dir === "right" ? width : -width, y: 0 },
      duration: 180,
      useNativeDriver: false,
    }).start(async () => {
      const swiped = topCard;
      pan.setValue({ x: 0, y: 0 });
      if (!swiped) return;

      setHistory((h) => [swiped, ...h]);
      setCards((c) => c.slice(1));

      try {
        if (dir === "right") {
          const res = await swipeRight(uid, swiped.uid);
          if (res.matched) {
            setMatchModal({
              visible: true,
              me: {
                uid: profile?.uid ?? uid,
                displayName: profile?.displayName ?? "You",
                photoURL: profile?.photoURL ?? null,
                birthday: profile?.birthday ?? null,
                bio: profile?.bio,
                occupation: profile?.occupation,
                gender: profile?.gender,
                age: undefined,
              },
              them: swiped,
            });
          }
        } else {
          await swipeLeft(uid, swiped.uid);
        }
      } catch (err) {
        console.error("❌ [forceSwipe] Swipe error:", err);
      }
    });
  };

  // ===== UI
  return (
    <LinearGradient colors={[PURPLE_BG1, PURPLE_BG2]} style={{ flex: 1 }}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: insets.top + 8 }]}>
        <Text style={styles.title}>💜 Flirt</Text>
        <TouchableOpacity style={styles.iconBtn}>
          <Ionicons name="options-outline" size={22} color="#4B0082" />
        </TouchableOpacity>
      </View>

      <View style={{ flex: 1, paddingHorizontal: 16, paddingTop: 8 }}>
        {loading ? (
          <Text
            style={{ textAlign: "center", color: GRAY_TEXT, marginTop: 24 }}
          >
            Đang tải danh sách…
          </Text>
        ) : !topCard ? (
          <Text
            style={{ textAlign: "center", color: GRAY_TEXT, marginTop: 24 }}
          >
            Hết ứng viên rồi 💔 Hãy quay lại sau nhé!
          </Text>
        ) : (
          <View style={{ flex: 1 }}>
            {nextCard && (
              <Card
                candidate={nextCard}
                style={{ position: "absolute", top: 0, left: 0, right: 0 }}
                elevation={1}
              />
            )}

            <Animated.View
              style={[
                {
                  transform: [
                    { translateX: pan.x },
                    { translateY: pan.y },
                    { rotate },
                  ],
                },
                { position: "absolute", left: 0, right: 0 },
              ]}
              {...panResponder.panHandlers}
            >
              <Card candidate={topCard} />
              <Animated.View
                style={[styles.badgeLike, { opacity: likeOpacity }]}
              >
                <Ionicons name="heart" size={70} color={PURPLE_DARK} />
              </Animated.View>
              <Animated.View
                style={[styles.badgeNope, { opacity: nopeOpacity }]}
              >
                <Ionicons name="close-circle" size={70} color="#F87171" />
              </Animated.View>
            </Animated.View>
          </View>
        )}
      </View>

      {/* Bottom actions */}
      <View style={[styles.actions, { paddingBottom: insets.bottom + 20 }]}>
        <Round onPress={() => forceSwipe("left")} bg="#fff">
          <Ionicons name="close" size={30} color="#F04D78" />
        </Round>
        <Round onPress={() => forceSwipe("right")} bg={PURPLE_DARK}>
          <Ionicons name="heart" size={28} color="#fff" />
        </Round>
      </View>

      {/* Match modal */}
      <Modal
        animationType="fade"
        transparent
        visible={matchModal.visible}
        onRequestClose={() => setMatchModal({ visible: false })}
      >
        <View style={styles.modalWrap}>
          <View style={styles.modalBox}>
            <Text style={styles.matchTitle}>💞 Match Found!</Text>
            <View style={{ flexDirection: "row", gap: 12, marginTop: 8 }}>
              <Avatar uri={matchModal.me?.photoURL} />
              <Avatar uri={matchModal.them?.photoURL} />
            </View>
            <Text
              style={{ color: GRAY_TEXT, textAlign: "center", marginTop: 8 }}
            >
              Hai bạn đã thích nhau! Hãy gửi lời chào đầu tiên 💬
            </Text>
            <TouchableOpacity
              style={[styles.chatBtn, { marginTop: 14 }]}
              onPress={() => setMatchModal({ visible: false })}
            >
              <Ionicons name="send" color="#fff" size={16} />
              <Text style={{ color: "#fff", fontWeight: "700", marginLeft: 6 }}>
                Say hi
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </LinearGradient>
  );
};

/* ====== Card Component ====== */
const Card = ({
  candidate,
  elevation = 3,
  style,
}: {
  candidate: Candidate;
  elevation?: number;
  style?: any;
}) => {
  const photo = candidate.photoURL || "https://i.pravatar.cc/400";
  const ageLabel =
    typeof candidate.age === "number" ? `, ${candidate.age}` : "";
  return (
    <View style={[styles.card, { elevation }, style]}>
      <Image source={{ uri: photo }} style={styles.cardImg} />
      <LinearGradient
        colors={["transparent", "rgba(0,0,0,0.65)"]}
        style={StyleSheet.absoluteFill}
      />
      <View style={styles.cardInfo}>
        <Text style={styles.cardName}>
          {candidate.displayName}
          {ageLabel}
        </Text>
        {candidate.occupation?.title ? (
          <View
            style={{ flexDirection: "row", alignItems: "center", marginTop: 4 }}
          >
            <Ionicons name="briefcase-outline" size={14} color="#EDE9FE" />
            <Text style={{ color: "#EDE9FE", marginLeft: 6 }}>
              {candidate.occupation.title}
              {candidate.occupation.company
                ? ` tại ${candidate.occupation.company}`
                : ""}
            </Text>
          </View>
        ) : null}
      </View>
    </View>
  );
};

const Round = ({
  children,
  onPress,
  bg = "#fff",
}: {
  children: React.ReactNode;
  onPress?: () => void;
  bg?: string;
}) => (
  <TouchableOpacity
    onPress={onPress}
    activeOpacity={0.9}
    style={[styles.round, { backgroundColor: bg }]}
  >
    {children}
  </TouchableOpacity>
);

const Avatar = ({ uri }: { uri?: string | null }) => (
  <Image
    source={{ uri: uri || "https://i.pravatar.cc/150" }}
    style={{ width: 72, height: 72, borderRadius: 16 }}
  />
);

/* ====== Styles ====== */
const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
  },
  title: {
    fontWeight: "800",
    fontSize: 22,
    color: "#6D28D9",
  },
  iconBtn: {
    backgroundColor: "#fff",
    borderRadius: 16,
    padding: 8,
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowRadius: 6,
    elevation: 2,
  },
  card: {
    width: CARD_W,
    height: CARD_H,
    borderRadius: 20,
    overflow: "hidden",
    alignSelf: "center",
    backgroundColor: "#ddd",
  },
  cardImg: { width: "100%", height: "100%" },
  cardInfo: { position: "absolute", left: 16, right: 16, bottom: 18 },
  cardName: { color: "#fff", fontWeight: "800", fontSize: 24 },
  badgeLike: {
    position: "absolute",
    top: 20,
    right: 20,
    transform: [{ rotate: "8deg" }],
  },
  badgeNope: {
    position: "absolute",
    top: 20,
    left: 20,
    transform: [{ rotate: "-8deg" }],
  },
  actions: {
    flexDirection: "row",
    justifyContent: "space-evenly",
    alignItems: "center",
  },
  round: {
    width: 70,
    height: 70,
    borderRadius: 999,
    alignItems: "center",
    justifyContent: "center",
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  modalWrap: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.35)",
    alignItems: "center",
    justifyContent: "center",
    padding: 20,
  },
  modalBox: {
    width: "100%",
    maxWidth: 340,
    borderRadius: 18,
    backgroundColor: "#fff",
    padding: 16,
    alignItems: "center",
  },
  matchTitle: { color: "#9333EA", fontWeight: "800", fontSize: 22 },
  chatBtn: {
    backgroundColor: "#9333EA",
    paddingHorizontal: 18,
    paddingVertical: 12,
    borderRadius: 14,
    flexDirection: "row",
    alignItems: "center",
  },
});

export default HomeScreen;
